'use strict';

const donacion1 = document.querySelector('.donacion-1');
const donacion2 = document.querySelector('.donacion-2');
const donacion3 = document.querySelector('.donacion-3');
const donacion4 = document.querySelector('.donacion-4');
const donacion5 = document.querySelector('.donacion-5');
const donacion6 = document.querySelector('.donacion-6');
const donacion7 = document.querySelector('.donacion-7');
const donacion8 = document.querySelector('.donacion-8');
const donacion9 = document.querySelector('.donacion-9');
const donacion10 = document.querySelector('.donacion-10');
const donacion11 = document.querySelector('.donacion-11');
const donacion12 = document.querySelector('.donacion-12');
const donacion13 = document.querySelector('.donacion-13');
const donacion14 = document.querySelector('.donacion-14');
const donacionContent1 = document.querySelector('.donacion-content-1');
const donacionContent2 = document.querySelector('.donacion-content-2');
const donacionContent3 = document.querySelector('.donacion-content-3');
const donacionContent4 = document.querySelector('.donacion-content-4');
const donacionContent5 = document.querySelector('.donacion-content-5');
const donacionContent6 = document.querySelector('.donacion-content-6');
const donacionContent7 = document.querySelector('.donacion-content-7');
const donacionContent8 = document.querySelector('.donacion-content-8');
const donacionContent9 = document.querySelector('.donacion-content-9');
const donacionContent10 = document.querySelector('.donacion-content-10');
const donacionContent11 = document.querySelector('.donacion-content-11');
const donacionContent12 = document.querySelector('.donacion-content-12');
const donacionContent13 = document.querySelector('.donacion-content-13');
const donacionContent14 = document.querySelector('.donacion-content-14');

donacion1.addEventListener("click", () => {

    donacionContent1.classList.remove("d-none");
    donacionContent2.classList.add("d-none");
    donacionContent3.classList.add("d-none");
    donacionContent4.classList.add("d-none");
    donacionContent5.classList.add("d-none");
    donacionContent6.classList.add("d-none");
    donacionContent7.classList.add("d-none");
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion2.addEventListener("click", () => {

    donacionContent2.classList.remove("d-none");
    donacionContent1.classList.add("d-none");
    donacionContent3.classList.add("d-none");
    donacionContent4.classList.add("d-none");
    donacionContent5.classList.add("d-none");
    donacionContent6.classList.add("d-none");
    donacionContent7.classList.add("d-none");
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");    

});

donacion3.addEventListener("click", () => {

    donacionContent3.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion4.addEventListener("click", () => {

    donacionContent4.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion5.addEventListener("click", () => {

    donacionContent5.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion6.addEventListener("click", () => {

    donacionContent6.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion7.addEventListener("click", () => {

    donacionContent7.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent8.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion8.addEventListener("click", () => {

    donacionContent8.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion9.addEventListener("click", () => {

    donacionContent9.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion10.addEventListener("click", () => {

    donacionContent10.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion11.addEventListener("click", () => {

    donacionContent11.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion12.addEventListener("click", () => {

    donacionContent12.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent13.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion13.addEventListener("click", () => {

    donacionContent13.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent14.classList.add("d-none");

});

donacion14.addEventListener("click", () => {

    donacionContent14.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add("d-none");
    donacionContent9.classList.add("d-none");
    donacionContent10.classList.add("d-none");
    donacionContent11.classList.add("d-none");
    donacionContent12.classList.add("d-none");
    donacionContent13.classList.add("d-none");

});